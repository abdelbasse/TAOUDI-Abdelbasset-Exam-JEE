package com.example.exam_final_jee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamFinalJeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamFinalJeeApplication.class, args);
	}

}
