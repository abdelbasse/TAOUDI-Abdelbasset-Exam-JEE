package com.example.exam_final_jee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamFinalJeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
